<?php
$app_strings['LBL_DASHBOARD_SHARE'] = "Share Dashboard";